Title {
Lab3
}
Status{
part A works perfect
part b one issue 
}
Known Issues{
issue with fork()
}
Expected Grade{ 70%}
